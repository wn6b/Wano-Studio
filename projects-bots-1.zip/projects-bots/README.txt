# Projects Bots — مروان | Wano
# دليل التشغيل الكامل على Termux

══════════════════════════════════════
  الخطوة 1 — تثبيت كل شيء (مرة واحدة)
══════════════════════════════════════

افتح Termux وانسخ هذه الأوامر واحد واحد:

# تحديث Termux
pkg update -y && pkg upgrade -y

# تثبيت Node.js
pkg install nodejs -y

# تثبيت wget
pkg install wget -y

# تحميل cloudflared
wget https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 -O $PREFIX/bin/cloudflared
chmod +x $PREFIX/bin/cloudflared

# إنشاء مجلد المشروع
mkdir -p ~/projects-bots/public

# انتقل للمجلد
cd ~/projects-bots

# تثبيت Express
npm install express


══════════════════════════════════════
  الخطوة 2 — نسخ الملفات
══════════════════════════════════════

ضع هذه الملفات في ~/projects-bots/:
  - server.js
  - package.json

وضع index.html في ~/projects-bots/public/


══════════════════════════════════════
  الخطوة 3 — تشغيل الموقع
══════════════════════════════════════

افتح تيرمنال أول — شغّل السيرفر:

  cd ~/projects-bots
  node server.js


══════════════════════════════════════
  الخطوة 4 — تشغيل الرابط العام
══════════════════════════════════════

افتح تيرمنال ثاني (اسحب من اليسار في Termux) — شغّل cloudflare:

  cloudflared tunnel --url http://localhost:3000

انتظر ثوانٍ وهيظهر رابط مثل:
  https://abc123xyz.trycloudflare.com

هذا رابطك العام! شاركه مع الناس.


══════════════════════════════════════
  ملاحظات مهمة
══════════════════════════════════════

- الرابط يتغير كل مرة تشغّل cloudflared من جديد
- السيرفر والنفق لازم يكونون شغالين مع بعض
- لو أغلقت Termux يتوقف كل شيء
- عشان يشتغل في الخلفية استخدم: nohup node server.js &


══════════════════════════════════════
  حقوق الموقع
══════════════════════════════════════

  Owner: مروان | Wano
  Discord: @wn6b
  YouTube: @wn5b
  TikTok: @w_n6b
  WhatsApp: +201145974113
