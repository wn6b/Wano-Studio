#!/data/data/com.termux/files/usr/bin/bash

echo "======================================"
echo "  Projects Bots - Setup Script"
echo "  مروان | Wano"
echo "======================================"
echo ""

# تحديث الباقات
echo "[1/6] تحديث Termux..."
pkg update -y && pkg upgrade -y

# تثبيت الأدوات الأساسية
echo "[2/6] تثبيت الأدوات..."
pkg install -y nodejs git wget curl

# تثبيت cloudflared
echo "[3/6] تثبيت Cloudflare Tunnel..."
wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64 -O $PREFIX/bin/cloudflared
chmod +x $PREFIX/bin/cloudflared

# إنشاء مجلد المشروع
echo "[4/6] إنشاء المشروع..."
mkdir -p ~/projects-bots
cd ~/projects-bots

# تثبيت express
echo "[5/6] تثبيت Express..."
npm init -y > /dev/null 2>&1
npm install express > /dev/null 2>&1

echo "[6/6] تم! الآن شغّل: bash start.sh"
echo ""
echo "✅ اكتمل التثبيت!"
