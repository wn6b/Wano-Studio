#!/data/data/com.termux/files/usr/bin/bash

cd ~/projects-bots
echo "🚀 تشغيل السيرفر..."
node server.js
