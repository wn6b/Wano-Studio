#!/data/data/com.termux/files/usr/bin/bash

echo ""
echo "🌐 تشغيل Cloudflare Tunnel..."
echo "انتظر ثوان وهيظهر رابط عام..."
echo ""

cloudflared tunnel --url http://localhost:3000

# الرابط هيظهر تلقائياً بهذا الشكل:
# https://xxxxxxxx.trycloudflare.com
