const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// إرسال الطلبات - endpoint
app.post('/order', (req, res) => {
  const { bot, name, contact, desc, budget, pay } = req.body;
  console.log('\n📦 طلب جديد وصل!');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(`البوت: ${bot}`);
  console.log(`العميل: ${name}`);
  console.log(`التواصل: ${contact}`);
  console.log(`الميزانية: ${budget}`);
  console.log(`الدفع: ${pay}`);
  console.log(`الوصف: ${desc}`);
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━\n');
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log('');
  console.log('╔══════════════════════════════════╗');
  console.log('║      Projects Bots - Wano        ║');
  console.log('║   مروان | Wano - @wn6b           ║');
  console.log('╚══════════════════════════════════╝');
  console.log('');
  console.log(`✅ السيرفر شغال على: http://localhost:${PORT}`);
  console.log('🌐 شغّل في تيرمنال ثاني: bash tunnel.sh');
  console.log('');
});
